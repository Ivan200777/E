package Entornos.entornos1.Proyecto;

public class Productos {
    private static int contadorId=1;// lo introduzco para ampliar un poco, metemos el id de los prodductos.


    private String nombre;
    private double precio;
    private String ID;

    //constructor
    public Productos (String nombre, double precio){
        this.nombre = nombre;
        this.precio = precio;
        this.ID = "P " + contadorId++;
    }

    //getters
    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public String getID() {
        return ID;
    }

    //setters

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setID(String iD) {
        ID = iD;
    }

    //Método para que podamos calcular el precio final total.

    public double calcularPrecioFinal(){
        return precio;
    }

    @Override 
    public String toString(){
        return nombre + "- Coste en euros: " + calcularPrecioFinal();
    }
}
